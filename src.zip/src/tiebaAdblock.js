$(function() {
    $('div[data-field=\"{\'author\':\'Fuck adblock!\'}\"]').remove();
});
